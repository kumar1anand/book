
import { Component, OnInit } from '@angular/core';
import {Observable, Subject} from 'rxjs';
import {ajax} from 'rxjs/ajax'

@Component({
  selector: 'app-rxjs',
  templateUrl: './rxjs.component.html',
  styleUrls: ['./rxjs.component.css']
})
export class RxjsComponent implements OnInit {

  // agents:Observable<String>
  constructor() { }

  ngOnInit(): void {

    // this.agents=new Observable(
    //   function(observer){
    //       try{
    //         observer.next('Ram');
    //         observer.next('reeta');
    //         observer.next('hari');
    //       }
    //       catch(e){
    //         observer.error(e)
    //       }
    //     }
    // )

    // this.agents.subscribe(data=>{
    //   console.log(data);
      
    // })


// Observable ex-1
    // const observables=new Observable(obj=>{
    //   obj.next(Math.random())
    // })

    // // subscribe1
    // observables.subscribe(d=>console.log(d))


    // // subscribe2
    // observables.subscribe(d=>console.log(d))


    // Observable ex-2
      // const data=ajax("https://jsonplaceholder.typicode.com/users")
    // data.subscribe(d=>console.log(d))
    // data.subscribe(d=>console.log(d))



    // Subject ex-1
    // const subject=new Subject()

    // // subscribe1
    // subject.subscribe(d=>console.log(d))

    // // subscribe1
    // subject.subscribe(d=>console.log(d))

    // subject.next(Math.random())

  // Subject ex-2
//   const subject=new Subject()
// const data=ajax("https://jsonplaceholder.typicode.com/users")
// subject.subscribe(d=>console.log(d))
// subject.subscribe(d=>console.log(d))
//     const res=data.subscribe(subject)

// const subject1=new Subject();
// const data1=ajax('https://jsonplaceholder.typicode.com/users');

// // subscribe 1
// subject1.subscribe(d=>console.log(d))

// // subscribe 2
// subject1.subscribe(d=>console.log(d))

// const res=data1.subscribe(subject1)
  }
  

}
