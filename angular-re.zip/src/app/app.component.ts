import { Component } from '@angular/core';
import { withLatestFrom } from 'rxjs';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'demoivy';
  public name='demo1';
  public image="https://cdn.britannica.com/45/5645-050-B9EC0205/head-treasure-flower-disk-flowers-inflorescence-ray.jpg"
  public value=" ";
  public colors=["red","green","blue"];
  display=false;
  public numbers="";
  stylecolor="white";
  txtColor="purple";

  public name1="prograd";
  public name2="IVY"
  public name3="welcome to prograd"
  public person={
    "fname":"ram",
    "sname":"roy"
  }
  public date=new Date()

  welcome(a,b){
    console.log("hello there"+a+b);
    
  }



// Reactive form
  loginForm=new FormGroup({
    user:new FormControl(''),
    password:new FormControl(' ')
  })
  loginUser(){
    console.log(this.loginForm.value);
    
  }


}
